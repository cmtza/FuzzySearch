package com.search;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class SearchMethods {


	public String add ( String intJson  ) throws Exception{
		String respuesta = "Usuario Agregado";

		JsonParser parser =  new JsonParser();
		JsonObject json  = (JsonObject) parser.parse(intJson);

		String nombre = json.get("name").getAsString();
		PrintWriter pw = null;
		FileWriter fichero =  null;
		try {
			fichero = new FileWriter("fuzzy-search.txt",true);
			pw = new PrintWriter(fichero);
			pw.println(nombre);

		} catch (IOException e) {
			throw new Exception("Error al consultar Archivo ");
		}finally {
			try {

				if (null != fichero)
					fichero.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}


		return respuesta;
	}


	public String list() throws Exception{
		String respuesta ="[]";
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		String linea;
		archivo = new File ("fuzzy-search.txt");
		 List nombres = new LinkedList<>();
        try {
			fr = new FileReader (archivo);
			 br = new BufferedReader(fr);
			 JSONArray jsonArray = new JSONArray();
			 JsonObject jsonObjetc =  null;
			

			 while((linea=br.readLine())!=null){
		            
				 nombres.add(linea);
			 }
		      
			 Collections.sort(nombres); 
			 
			 
			 for (int i  = 0  ; i< nombres.size();i++) {
				 
		            jsonObjetc =  new JsonObject();
		            jsonObjetc.addProperty("name", nombres.get(i).toString());
		            jsonArray.put(jsonObjetc);
		        }

			respuesta =  jsonArray.toString();
			 
		} catch (FileNotFoundException e) {
			throw new Exception("Error al consultar Archivo ");
		}finally{

	         try{                    
	            if( null != fr ){   
	               fr.close();     
	            }                  
	         }catch (Exception e2){ 
	            e2.printStackTrace();
	         }
	      }
       

		return respuesta;
	}
	
	
	public String fuzzySearch(String jsaonsearch) throws Exception{
		String respuesta = "Sin coincidencias";
		
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		String cadena;
		archivo = new File ("fuzzy-search.txt");
		JsonParser parser =  new JsonParser();
		JsonObject json  = (JsonObject) parser.parse(jsaonsearch);
		int contaux = 0,contActu = 0;
		String buscar = json.get("search").getAsString();
		buscar =  buscar.toUpperCase();
		
		try {
			fr = new FileReader (archivo);
			 br = new BufferedReader(fr);
				
			 while((cadena=br.readLine())!=null){
				 contaux = 0;
					for(int j=0 ; j <buscar.length();j++){
						if(cadena.toUpperCase().replace(" ", "").contains(buscar.substring(j, j+1))){
							contaux++;
						}
					}
				if (contaux>contActu){
					respuesta = cadena;
					contActu = contaux;
				}	
					
			 }
			
		} catch (FileNotFoundException e) {
			throw new Exception("Error al consultar Archivo ");
		}
		
		
		return respuesta;
		
	}
	
	
}
