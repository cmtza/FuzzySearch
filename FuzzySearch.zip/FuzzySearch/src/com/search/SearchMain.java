package com.search;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SearchMain {


	public static void main (String[] args){
		SearchMethods sear = new SearchMethods();
		Scanner sn = new Scanner(System.in);
		boolean salir = false;
		int opcion; 

		while (!salir) {

			System.out.println("1. add");
			System.out.println("2. list");
			System.out.println("3. fuzzy-search");
			System.out.println("4. Salir");

			try {

				System.out.println("Escribe una de las opciones");
				opcion = sn.nextInt();
				String json = "";

				switch (opcion) {
				case 1:
					System.out.println("Ingrese el JSon para agregar un nombre :: ");
					 sn = new Scanner(System.in);
					 json  =  sn.nextLine();
					try {
						System.out.println(sear.add(json));
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 2:
					try {
						System.out.println(sear.list());
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 3:
					System.out.println("Ingrese el JSon para buscar un nombre ::");
					 sn = new Scanner(System.in);
					json  =  sn.nextLine();
					try {
						System.out.println(sear.fuzzySearch(json));
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 4:
					salir = true;
					break;
				default:
					System.out.println("Solo n�meros entre 1 y 4");
				}
			} catch (InputMismatchException e) {
				System.out.println("Debes insertar un n�mero");
				sn.next();
			}
		}

	}
}
